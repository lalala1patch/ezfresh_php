<?php
include "start.php";
include "main-header.php";
?>

<div class="container p-4">
<h3><b>Contact Us</b></h3>
    <p>Please send your feedback, comments, requests for technical support by email: <b>sandeshjoshi2211@gmail.com</b>.</p>

   
    <!-- For MAP -->
            <br>
<h3><b>Find us on Google Map</b></h3>

            <div class="mapouter mb-3"><div class="gmap_canvas"><iframe width="100%" height="500" id="gmap_canvas" src="https://maps.google.com/maps?q=Trade%20tower%20The%20british%20college&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><a href="https://www.whatismyip-address.com"></a><br>
            </div>
            </div>
        </div>
            <style>
                .mapouter{
                    position:relative;
                    text-align:right;
                    height:500px;
                    width:100%;
                }
            </style>
            <style>.gmap_canvas {
                overflow:hidden;
                background:none!important;
                height:500px;width:100%;
                }
            </style>
<?php
include "main-footer.php";
include "end.php";
?>