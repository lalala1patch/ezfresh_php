<html>
    <body style="color: #000; font-size: 15px; text-decoration: none; font-family: 'ABeeZee', sans-serif; background-color: #efefef; margin: 100px;">
        <div id="wrapper" style=" max-width: 1100px; margin: auto auto; padding: 20px; box-shadow: 3px 3px 6px 6px #888888;">
            <div id="logo">
                <center>
                    <h1 style="margin: 0px;">
                        <a href="http://localhost/ezfresh/homeEZFRESH.php" target="_blank">
                            <img style="max-height: 75px;" src="https://user-images.githubusercontent.com/66363471/169642857-433f7252-c424-4b2c-9298-86749cef2298.png" >
                        </a>
                    </h1>
                </center>
            </div>

            <div style="color: white; display:flex; justify-content:center; background-color:#4287f5; height: auto;">
                <h1 style="letter-spacing: 5px;">INVOICE</h1>
            </div>

            <div id="content" style="justify-content:center; font-size: 15px; padding: 25px; background-color: #fff; height: auto; margin: auto auto;">
                <div style="float: right; ">   
                    <p>Invoice NO:<b> '.$payerid.'</b></p>
                    <p>Invoice Date:<b> '.$odate1.'</b></p>
                    <p>Order Date:<b> '.$odate1.'</b></p>
                </div>
                
                <div style="display: block;">                
                    <p>Billed To: </p>
                    <p>Customer Name:<b> '.$cname1.'</b></p>
                    <p>Customer Address:<b> '.$address1.'</b></p>
                </div>
                            <br>
                <div style="display: block;">                
                <p>Sold By: </p>
                <p>Trader Name:<b> '.$tname.'</b></p>
                <p>Shop Name:<b> '.$sname.'</b></p>
                <p>Address:<b> '.$taddress.'</b></p>
                <p>Seller Email:<b> '.$email1.'</b></p>
                </div>
                            <br>
                <div style="display: block; ">                
                <p>Payment Method:<b> Paypal</b></p>
                </div>

                <table style="width:100%; border-style: solid; border-width:1px; border-color:#000000; border-collapse: collapse;">
                    <tr style="text-align: center;">
                        <th style="border-right-style: groove;">SN</th>
                        <th>Product ID</th>
                        <th>Product Name</th>
                        <th>Product Description</th>
                        <th>Qty</th>
                        <th>Unit Cost</th>
                        <th>Total Price</th>
                    </tr>

                    <tr style="text-align: center;">
                        <!-- <td>'.$s.'</td>
                        <td>'.$row['PRODUCT_ID'].'</td>
                        <td>'.$row['PRODUCT_NAME'].'</td>
                        <td>'.$row['PRODUCT_DESCRIPTION'].'</td>
                        <td>'.$row['QUANTITY'].'</td>
                        <td>'.$row['PRODUCT_PRICE'].'</td>
                        <td>'.$row['ORDER_PRICE'].'</td>
                        </tr>'; -->
                        <td style="border-right-style: groove;">1</td>
                        <td>1008</td>
                        <td>Apple</td>
                        <td style="text-align: left !important; width: 50%;">Carrots are long, thin, orange-colored vegetables. Carrots are a popular vegetable to eat raw on their own or chopped and tossed in a salad.</td>
                        <td>3</td>
                        <td>3</td>
                        <td>9</td>
                    </tr>
                </table>
                <div style="text-align:right;">
                    <h4>Grand Total: 9</h4>
                </div>
            </div>
        </div>
    </body>
</html>