<?php
    include "start.php";
    include "main-header.php";
    include "manage_search.php";
?>
<style>
    #productDetails{
        text-decoration: none;
    }
    .card:hover #add {
        opacity: 1;
        transition: .5s;
    }
    #productDetails img:hover{
        transform: scale(1.09);
        transition: .5s;
    }
    @media(max-width: 992px)
    {
        *{
            font-size: x-small;
        }   
    }
</style>

<div class="container">
    <div class="row">
        <div class=" col-lg-3">
            <h5 class="mt-3 text-center">SORT BY</h5>

            <div class="row m-1">
                <div class="mb-3 p-3 border border-dark">
                    <div class="h5 pt-2">Price</div>
                    <div class="text-align-center">
                        <form action="product_search.php" method="POST">
                            <input class="mb-2" type="text" placeholder="Min" name="min"/> 
                            <input  class="mb-2" type="text" placeholder="Max" name="max"/><br>
                            <button class="btn btn-success" name="minmax">GO</button>
                        </form>
                    </div>
                </div>
                <form class="border border-dark p-3" method="POST" action="product_search.php">
                    <div class="h5 pt-2">Shops</div>
                    <div class="form-check">
                        <input type="radio" class="form-check-input" name="shops" id="shop1" value="Pure Vegetables"/>
                        <label for="shop1" class="form-check-label">Pure Vegetables</label>
                    </div>
                    <div class="form-check">
                        <input type="radio" class="form-check-input" name="shops" id="shop2" value="Fruit Basket"/>
                        <label for="shop2" class="form-check-label">Fruit Basket</label>
                    </div>
                    <div class="form-check">
                        <input type="radio" class="form-check-input" name="shops" id="shop3" value="The Perfect Meat"/>
                        <label for="shop3" class="form-check-label">The Perfect Meat</label>
                    </div>
                    <div class="form-check">
                        <input type="radio" class="form-check-input" name="shops" id="shop4" value="Meat Snacks"/>
                        <label for="shop4" class="form-check-label">Meat Snackss</label>
                    </div>
                    <div class="form-check">
                        <input type="radio" class="form-check-input" name="shops" id="shop5" value="Sea Breeze"/>
                        <label for="shop5" class="form-check-label">Sea Breeze</label>
                    </div>
                    <div class="form-check">
                        <input type="radio" class="form-check-input" name="shops" id="shop6" value="Ocean Blue"/>
                        <label for="shop6" class="form-check-label">Ocean Blue</label>
                    </div>
                    <div class="form-check">
                        <input type="radio" class="form-check-input" name="shops" id="shop7" value="The Bakery Room"/>
                        <label for="shop7" class="form-check-label">The Bakery Room</label>
                    </div>
                    <div class="form-check">
                        <input type="radio" class="form-check-input" name="shops" id="shop8" value="The Eatery"/>
                        <label for="shop8" class="form-check-label">The Eatery</label>
                    </div>
                    <div class="form-check">
                        <input type="radio" class="form-check-input" name="shops" id="shop9" value="Deli Explorer"/>
                        <label for="shop9" class="form-check-label">Deli Explorer</label>
                    </div>
                    <div class="form-check">
                        <input type="radio" class="form-check-input" name="shops" id="shop10" value="Lazy Lunch"/>
                        <label for="shop10" class="form-check-label">Lazy Lunch</label>
                    </div>
                    <button class="btn btn-success mt-2" type="submit" name="shopSubmit">GO</button>
                </form>
            </div>
        </div>

        <div class=" col-lg-9">
            <div class="container border border-dark mt-5 mb-2">
                <div class="row p-3">
                    <h6><b>
                    <?php
                        echo $count;
                    ?></b>
                    result found for <b><?php  if(isset($_GET['searchtxt']))
                                             {
                                                 echo "'".$_GET['searchtxt']."'";
                                             } 
                                             if(isset($_POST['shopSubmit']))
                                             {
                                                echo "'". $shopname ."'";
                                             }
                                             if(isset($_POST['minmax']))
                                             {
                                                echo "$". $min ." - $". $max ." price range";
                                             }
                                             if(isset($_GET['category']))
                                             {
                                                echo "'".$_GET['category']."'";
                                             }
                                             ?></b>
                    </h6>
                </div>
            </div>

            <div class="container border border-dark mb-3">
                <div class="row p-3">
                    <div class='row d-flex justify-content-around my-4'>
                            <?php 
                            if(empty($_GET['searchtxt']) && empty($_POST['shops']) && empty($_POST['min']) && empty($_POST['max']) && empty($_GET['category']))
                                {
                                    echo "No results";
                                }
                            ?>
                    <?php
                      
                        for($counter = 0; $counter < $count; $counter++)
                        {
                            echo
                            "
                                    <div class='card border-0' style='width: 12rem; border border-dark'>
                                        <a id='productDetails' href='productDetail.php?product_id=$product_id[$counter]'>
                                            <img style='width: 12rem; height: 12rem;' class='card-img-top border shadow p-3' src='$product_image[$counter]' alt='Card image cap'>

                                            <div class='card-body text-center'>
                                                <h5 class='card-title'><strong>$product_name[$counter]</strong></h5>
                                                <h5 class='card-title'>$$product_price[$counter]</h5>
                                            </div>
                                        </a>
                                    </div>
                            ";
                        }
                    ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
    include "end.php";
    include "main-footer.php";
?>