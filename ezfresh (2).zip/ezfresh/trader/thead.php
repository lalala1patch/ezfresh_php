<style>
    *{
        margin: 0;
        padding: 0;
    }
    .header{
        background-color: #f3f0eb;
        height: 90px;
        text-align: center;
    }
    #logo{
        width: 280px;
		height: 90px;
    }
</style>

<div class="header" >
    <a href="../homeEZFRESH.php"><img id="logo" src="../logo/logo.png"></a>
</div>