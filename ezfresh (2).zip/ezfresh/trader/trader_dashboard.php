<?php
    include "t_header.php";
?>

<?php
// trader id 
    if(isset($_GET['id']))
    {
        $tid = $_GET['id'];

        include "connect.php";
        $qryy = "SELECT * FROM TRADER WHERE TRADER_ID=$tid";
        $res = oci_parse($conn, $qryy);
        oci_execute($res);

        while($row = oci_fetch_assoc($res))
        {
            $t_fullname = $row['FULL_NAME'];
            $t_email = $row['EMAIL'];
        }
    }
?>

<div class="container">
    <div class="container w-75 border border-dark">
        <div class="h4 p-2">WELCOME <b>'<?php echo $t_fullname ?>'</b>. This is your dashboard</div>
    </div>
    <div class="container w-75 mt-4">
        <div class="row d-flex justify-content-center">
            <div class="col-4 border border-dark d-flex flex-column align-items-center justify-content-center">
                <span style="font-size: 7vw;">##</span><br>
                <h4 class="mb-5">TOTAL ORDERS</h4>
            </div>
            <div class="col-4 border border-dark d-flex flex-column align-items-center justify-content-center">
                <span style="font-size: 7vw;">##</span><br>
                <h4 class="mb-5">Number of Products</h4>
            </div>
            <div class="col-4 border border-dark d-flex flex-column align-items-center justify-content-center">
                <span style="font-size: 7vw;">##</span><br>
                <h4 class="mb-5">Earnings</h4>
            </div>
        </div>
    </div>
</div>

<?php
    include "../main-footer.php";
?>